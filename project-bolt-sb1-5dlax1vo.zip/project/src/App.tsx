import React from 'react';
import { ArrowRight, CheckCircle, Users, Target, TrendingUp, Shield, MessageCircle, Star, Zap, Heart, Award, Globe } from 'lucide-react';

function App() {
  const whatsappUrl = "https://wa.me/5491124620014";

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: "url('https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')"
          }}
        ></div>
        
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-purple-900/80"></div>
        
        <div className="relative z-10 container mx-auto px-6 py-20 flex flex-col justify-center min-h-screen">
          <div className="max-w-4xl mx-auto text-center">
            {/* Badge */}
            <div className="inline-flex items-center px-4 py-2 bg-yellow-500/20 border border-yellow-400/30 rounded-full text-yellow-300 text-sm font-medium mb-8">
              <Zap className="w-4 h-4 mr-2" />
              Mentoría Personalizada Disponible
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              De la <span className="text-yellow-400">Duda</span> al{' '}
              <span className="text-yellow-400">Éxito</span>:<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 to-purple-300">
                Crea tu Negocio Digital
              </span><br />
              con JUANMA NEGOCIOS DIGITALES
            </h1>

            <p className="text-xl md:text-2xl mb-12 text-blue-100 leading-relaxed max-w-3xl mx-auto">
              Descubre cómo transformé mis miedos en un ingreso principal y estable, y cómo tú también puedes hacerlo desde el primer día con mi mentoría personalizada.
            </p>

            <a 
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-bold text-lg rounded-full shadow-2xl transform transition-all duration-300 hover:scale-105 hover:shadow-yellow-500/50 hover:from-yellow-400 hover:to-yellow-500"
            >
              🔥 Quiero Empezar Hoy
              <ArrowRight className="ml-2 w-5 h-5" />
            </a>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-400">24H</div>
                <div className="text-blue-200">Primeros resultados</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-400">100%</div>
                <div className="text-blue-200">Mentoría personalizada</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-400">∞</div>
                <div className="text-blue-200">Potencial de ingresos</div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave decoration */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1200 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,96L48,112C96,128 192,160 288,160C384,160 480,128 576,112C672,96 768,96 864,112C960,128 1056,160 1152,160C1200,160 1248,128 1296,112L1344,96L1344,320L1296,320C1248,320 1200,320 1152,320C1056,320 960,320 864,320C768,320 672,320 576,320C480,320 384,320 288,320C192,320 96,320 48,320L0,320Z" fill="white"/>
          </svg>
        </div>
      </section>

      {/* Historia Personal */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-6 text-gray-800">
                  Mi Camino: De la{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
                    Inseguridad
                  </span>{' '}
                  a la{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-500 to-orange-500">
                    Libertad Financiera
                  </span>
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed mb-8">
                  Hubo un tiempo en el que yo también dudaba... no tenía experiencia, ni conocimientos técnicos, solo una gran necesidad de cambio. Probé muchas cosas, cometí errores, pero encontré un camino claro: los productos y servicios digitales.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed mb-8">
                  <strong className="text-blue-600">Hoy vivo de esto.</strong> Y quiero mostrarte cómo tú también puedes hacerlo, sin complicaciones y con resultados desde el primer día.
                </p>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <Heart className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800">Con pasión y dedicación</p>
                    <p className="text-gray-600">Transformando vidas, un negocio a la vez</p>
                  </div>
                </div>
              </div>
              <div className="relative">
                <img 
                  src="https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=2"
                  alt="Éxito empresarial"
                  className="rounded-2xl shadow-2xl w-full"
                />
                <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border-l-4 border-yellow-500">
                  <p className="font-bold text-gray-800">Mi transformación</p>
                  <p className="text-sm text-gray-600">De empleado a empresario digital</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Beneficios */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto text-center">
            <h2 className="text-5xl font-bold mb-4 text-gray-800">
              ¿Qué vas a{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
                lograr
              </span>{' '}
              conmigo?
            </h2>
            <p className="text-xl text-gray-600 mb-16 max-w-2xl mx-auto">
              Resultados concretos que transformarán tu realidad financiera
            </p>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: <Zap className="w-8 h-8" />,
                  title: "Crear tu propio negocio digital desde cero",
                  description: "Sin experiencia previa, con las herramientas y estrategias correctas"
                },
                {
                  icon: <TrendingUp className="w-8 h-8" />,
                  title: "Vender productos y servicios digitales de alta demanda",
                  description: "Productos probados que el mercado necesita y está dispuesto a comprar"
                },
                {
                  icon: <Target className="w-8 h-8" />,
                  title: "Generar ingresos diarios desde el primer día",
                  description: "Sistema optimizado para resultados inmediatos y consistentes"
                },
                {
                  icon: <Award className="w-8 h-8" />,
                  title: "Tener una estrategia personalizada adaptada a ti",
                  description: "Plan único diseñado según tu perfil, objetivos y disponibilidad"
                },
                {
                  icon: <Users className="w-8 h-8" />,
                  title: "Contar con un mentor que te acompaña paso a paso",
                  description: "Seguimiento personal y directo para garantizar tu éxito"
                },
                {
                  icon: <Globe className="w-8 h-8" />,
                  title: "Integrarte en una comunidad activa que te apoya",
                  description: "Red de emprendedores que comparten experiencias y se ayudan mutuamente"
                }
              ].map((benefit, index) => (
                <div key={index} className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 mx-auto text-white group-hover:scale-110 transition-transform duration-300">
                    {benefit.icon}
                  </div>
                  <h3 className="font-bold text-xl mb-4 text-gray-800 leading-tight">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {benefit.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Qué Incluye */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-5xl font-bold mb-4 text-gray-800">
              Tu{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-500 to-orange-500">
                Kit de Éxito
              </span>{' '}
              Digital
            </h2>
            <p className="text-xl text-gray-600 mb-16">
              Todo lo que necesitas para triunfar está incluido
            </p>

            <div className="grid md:grid-cols-2 gap-6 text-left">
              {[
                "Asesoría personalizada 1:1",
                "Plan de acción adaptado a ti",
                "Acceso inmediato a productos digitales para vender",
                "Entrenamientos prácticos (sin tecnicismos)",
                "Seguimiento diario + comunidad de apoyo"
              ].map((item, index) => (
                <div key={index} className="flex items-start space-x-4 p-4 rounded-xl bg-green-50 border border-green-200 hover:bg-green-100 transition-colors duration-300">
                  <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                  <span className="text-lg font-medium text-gray-800">{item}</span>
                </div>
              ))}
            </div>

            <div className="mt-12 p-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl text-white">
              <h3 className="text-2xl font-bold mb-4">🎁 Bonus Exclusivo</h3>
              <p className="text-lg opacity-90">
                Acceso de por vida a actualizaciones y nuevas estrategias
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Intermedio */}
      <section className="py-16 bg-gradient-to-r from-yellow-500 to-orange-500">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-6 text-black">
            ¿Estás listo para comenzar HOY?
          </h2>
          <p className="text-xl mb-8 text-black/80 max-w-2xl mx-auto">
            No necesitas experiencia, solo las ganas de cambiar tu vida. Te acompaño paso a paso. Hoy puede ser el primer día de tu nueva historia.
          </p>
          <a 
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-4 bg-black text-white font-bold text-lg rounded-full shadow-2xl transform transition-all duration-300 hover:scale-105 hover:shadow-xl"
          >
            🚀 Sí, quiero empezar ya
            <ArrowRight className="ml-2 w-5 h-5" />
          </a>
        </div>
      </section>

      {/* Testimonios */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto text-center">
            <h2 className="text-5xl font-bold mb-4 text-gray-800">
              Historias{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-blue-500">
                reales
              </span>
              , resultados{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-blue-500">
                reales
              </span>
            </h2>
            <p className="text-xl text-gray-600 mb-16">
              Lo que dicen las personas que ya transformaron su vida
            </p>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Testimonio Rocío */}
              <div className="bg-white p-8 rounded-2xl shadow-xl border-l-4 border-green-500">
                <div className="flex items-center mb-6">
                  <img 
                    src="https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2"
                    alt="Rocío"
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-bold text-lg text-gray-800">Rocío</h4>
                    <div className="flex text-yellow-500">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic leading-relaxed">
                  "Mi primera venta fue en 24 horas. Hoy vivo de esto. Gracias Juanma que ayudó a crecer rápido. Super recomendable FENIX DIGITAL"
                </p>
                <div className="mt-4 flex items-center text-green-600">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  <span className="font-semibold">Primera venta en 24h</span>
                </div>
              </div>

              {/* Testimonio Theo */}
              <div className="bg-white p-8 rounded-2xl shadow-xl border-l-4 border-blue-500">
                <div className="flex items-center mb-6">
                  <img 
                    src="https://images.pexels.com/photos/3777943/pexels-photo-3777943.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2"
                    alt="Theo"
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-bold text-lg text-gray-800">Theo</h4>
                    <div className="flex text-yellow-500">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic leading-relaxed">
                  "Desde que ingresé a Fenix no paro de vender. Gracias a Juanma con su mentoría personalizada con su estrategia y seguimiento hoy vivo de esto. Super agradecido y lo recomiendo al 100%."
                </p>
                <div className="mt-4 flex items-center text-blue-600">
                  <Target className="w-5 h-5 mr-2" />
                  <span className="font-semibold">Ventas constantes</span>
                </div>
              </div>
            </div>

            {/* Estadísticas de éxito */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">98%</div>
                <div className="text-gray-600">Tasa de éxito</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">24H</div>
                <div className="text-gray-600">Primeros resultados</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">500+</div>
                <div className="text-gray-600">Estudiantes exitosos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-600">∞</div>
                <div className="text-gray-600">Potencial ilimitado</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Comunidad */}
      <section className="py-20 bg-gradient-to-br from-purple-900 to-blue-900 text-white">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-5xl font-bold mb-6">
                  No estás solo.<br />
                  Somos una{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-400">
                    comunidad
                  </span>{' '}
                  que vuela alto. 🔥
                </h2>
                <p className="text-xl text-purple-100 leading-relaxed mb-8">
                  En Fénix Digital no solo aprenderás a ganar dinero. Formarás parte de una comunidad donde todos vamos en la misma dirección. Nos apoyamos, compartimos experiencias y celebramos cada éxito juntos.
                </p>

                <div className="space-y-4">
                  {[
                    "Grupo exclusivo de WhatsApp",
                    "Sesiones grupales semanales",
                    "Intercambio de estrategias exitosas",
                    "Red de contactos empresariales",
                    "Apoyo mutuo 24/7"
                  ].map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-yellow-400" />
                      <span className="text-purple-100">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="relative">
                <img 
                  src="https://images.pexels.com/photos/3184431/pexels-photo-3184431.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=2"
                  alt="Comunidad Fénix Digital"
                  className="rounded-2xl shadow-2xl w-full"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent rounded-2xl"></div>
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="bg-white/90 backdrop-blur-sm p-4 rounded-xl">
                    <p className="font-bold text-gray-800 text-lg">Comunidad Fénix Digital</p>
                    <p className="text-gray-600">Juntos hacia el éxito 🚀</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Garantía */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-green-500 to-blue-500 rounded-full mb-8">
              <Shield className="w-10 h-10 text-white" />
            </div>
            
            <h2 className="text-5xl font-bold mb-6 text-gray-800">
              Empieza{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-blue-500">
                sin miedo
              </span>
            </h2>
            
            <p className="text-xl text-gray-600 leading-relaxed mb-12 max-w-2xl mx-auto">
              No necesitas conocimientos previos, ni hacer inversiones riesgosas. Esta es una oportunidad real, probada, y guiada de principio a fin.
            </p>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="p-6 bg-green-50 rounded-xl border border-green-200">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2 text-gray-800">Sin riesgos</h3>
                <p className="text-gray-600">Inversión mínima con retorno garantizado</p>
              </div>

              <div className="p-6 bg-blue-50 rounded-xl border border-blue-200">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2 text-gray-800">Acompañamiento total</h3>
                <p className="text-gray-600">Seguimiento personalizado paso a paso</p>
              </div>

              <div className="p-6 bg-purple-50 rounded-xl border border-purple-200">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2 text-gray-800">Resultados probados</h3>
                <p className="text-gray-600">Estrategias ya validadas por cientos</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-orange-500/10"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-6xl font-bold mb-8">
              ¡Tu{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-400">
                momento
              </span>{' '}
              es AHORA!
            </h2>
            
            <p className="text-2xl mb-12 text-blue-100 leading-relaxed">
              No dejes que otro día pase sin actuar. Tu nueva vida te está esperando.
            </p>

            <div className="space-y-6">
              <a 
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-12 py-6 bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold text-2xl rounded-full shadow-2xl transform transition-all duration-300 hover:scale-110 hover:shadow-yellow-500/50"
              >
                🔥 Quiero transformar mi vida ahora
                <MessageCircle className="ml-3 w-6 h-6" />
              </a>
              
              <p className="text-blue-200">
                📱 Te respondo personalmente en WhatsApp
              </p>
            </div>

            <div className="mt-16 p-8 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
              <p className="text-lg text-blue-100 mb-4">
                <strong className="text-white">¿Tienes dudas?</strong> Hablemos sin compromiso
              </p>
              <p className="text-blue-200">
                Contáctame y resolveré todas tus preguntas antes de empezar
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-gray-900 text-white">
        <div className="container mx-auto px-6 text-center">
          <div className="mb-8">
            <h3 className="text-2xl font-bold mb-2">JUANMA NEGOCIOS DIGITALES</h3>
            <p className="text-gray-400">Transformando vidas a través del emprendimiento digital</p>
          </div>
          
          <div className="border-t border-gray-800 pt-8">
            <p className="text-gray-400">
              © 2025 JUANMA NEGOCIOS DIGITALES. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;